# Easyhospital

Its a Medical info based personal demo app. It is my first building app. I made it for my OOP course . 
