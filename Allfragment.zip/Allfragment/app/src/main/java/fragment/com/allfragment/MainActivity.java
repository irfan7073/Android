package fragment.com.allfragment;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void changeFragment (View view){

       Fragment fragment;

        if (view == findViewById(R.id.btn1)){

            fragment=new BlankFragment();
            FragmentManager fm=getSupportFragmentManager();
            FragmentTransaction ft =fm.beginTransaction();
            FragmentTransaction replace;
            replace = ft.replace(R.id.fragment_place,fragment);
            ft.commit();

        }
        if (view == findViewById(R.id.btn2)){
            fragment=new Fragment2();
            FragmentManager fm=getSupportFragmentManager();
            FragmentTransaction ft =fm.beginTransaction();
            FragmentTransaction replace;
            replace = ft.replace(R.id.fragment_place,fragment);
            ft.commit();

        }
    }
}
