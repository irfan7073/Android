package com.example.ckbur.listviewassignment;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<viewHolder>items;

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=(ListView)findViewById(R.id.messageListView);
        items=new ArrayList<>();


        items.add(new viewHolder("John Clington","CEO","USD 21000$",R.drawable.ceo));
        items.add(new viewHolder("Gray Jonathan","Senior Developer","USD 11000$",R.drawable.seniordeveloperm));
        items.add(new viewHolder("Barbara Young","Senior Developer","USD 10000$",R.drawable.seniordeveloperw));
        items.add(new viewHolder("Brown Williomsan","Developer","USD 8000$",R.drawable.developerm));
        items.add(new viewHolder("Linda Adams","Developer","USD 8000$",R.drawable.developerw));


        ListAdepter adepter=new ListAdepter(this,R.layout.item_list,items);
        listView.setAdapter(adepter);


      listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          @Override
          public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
              Toast.makeText(getApplicationContext(), "This is my Toast message!",
                      Toast.LENGTH_LONG).show();
          }
      });




    }


}
