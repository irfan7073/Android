package com.example.ckbur.listviewassignment;

import android.app.Activity;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ListAdepter extends ArrayAdapter<viewHolder> {

    public int resourceLayout;
    private Context mContext;
    List<viewHolder>items;
    public ListAdepter(Context context, int resource, List<viewHolder>items) {
        super(context, resource, items);
        this.resourceLayout = resource;
        this.mContext = context;
        this.items=items;


    }



    @Override
    public View getView(int position, View convertView,ViewGroup parent) {

        if (convertView == null){
            convertView=((Activity)getContext()).getLayoutInflater().inflate(R.layout.item_list,parent,false);
        }
        TextView tv1 = convertView.findViewById(R.id.nameTextView);
        TextView tv2 = convertView.findViewById(R.id.messageTextView1);
        TextView tv3= convertView.findViewById(R.id.messageTextView2);
        ImageView iv1 = convertView.findViewById(R.id.image_message);


        viewHolder v=items.get(position);
        tv1.setText(v.getTv1());
        tv2.setText(v.getTv2());
        tv3.setText(v.getTv3());
        iv1.setImageDrawable(mContext.getResources().getDrawable(v.getIv1()));



        return convertView;


    }
}
